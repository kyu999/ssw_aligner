SSW Aligner

### Dependencies
- [Numpy==1.12.0](http://www.numpy.org/)

### Reference
- [scikit-bio](https://github.com/biocore/scikit-bio)
